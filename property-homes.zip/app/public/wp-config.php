<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', 'root' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          '0ip|e fHnE?99+zA,.@/;Bh$pFc+6[)c8L;cj.>`reDt[._&C>aw6|uWZmC{ls7Q' );
define( 'SECURE_AUTH_KEY',   '.mpz%+Bnv;sCHMLX/ez/<M*PW=y`J}jb`8U3{yKhLB5omH J0QN6M[{!cjx!oTdt' );
define( 'LOGGED_IN_KEY',     ' sFdz!7nT{*&_0AixhszD~,VyrM*p;KU|1nc.gmm3b}B)j{/{5Pk,MC.aYT3l4Q|' );
define( 'NONCE_KEY',         '58jLSM:0(MCVDZA<bF<EVe$9*Gt+5H&FC=AV0,CFlrXeWqTxPmPy}yU)R)<46tVN' );
define( 'AUTH_SALT',         '<w~l>isC6aNCk[H;}==Urk[GU9cH0Hg(()Y~2mcI]_xThUly%bYs8#k#A-.`sxD:' );
define( 'SECURE_AUTH_SALT',  'N?hg0YKJQo+&c7Ii4,Xeg-b9RP`Jj2N9AGB0Nc:Wgq3s[,?i@ 7&Lc{aN:wS%lOF' );
define( 'LOGGED_IN_SALT',    'G]^y}^*q<Xnpd_J4|CfuPumZ416L01hx9k^O,oTi$Llgav+11ICd]/y^t[lVFhFk' );
define( 'NONCE_SALT',        'mv5tV~`ft>r6TGvV!sNlfEuo:<i]Um#rbE%@zq_I$x4Ub]f.-G/>.f}:ow DNDO-' );
define( 'WP_CACHE_KEY_SALT', 'mbBDi5-S_,-Hv1Y?5#]XE#+p+~|2U5DZ#.&cb+8w<I-q?&+u=MF;#b<qNv:Yb}[;' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


/* Add any custom values between this line and the "stop editing" line. */



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}

define( 'WP_ENVIRONMENT_TYPE', 'local' );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
